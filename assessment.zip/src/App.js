import './App.css';
import TodoList from './pages/Todos';
function App() {
  return (
    <div className="App">
     <TodoList />
    </div>
  );
}

export default App;
